<!DOCTYPE html>
<html>
<head>
    <title>JSON Content</title>
</head>
<body>
    <h1>JSON Content:</h1>
    <?php if($data): ?>
        <pre><?php echo e(print_r($data["makananPokok"][0]['id'])); ?></pre>
    <?php else: ?>
        <p><?php echo e($error); ?></p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH E:\APP DATA\XAMpp\htdocs\JOKI 1\job\resources\views/jsonview.blade.php ENDPATH**/ ?>